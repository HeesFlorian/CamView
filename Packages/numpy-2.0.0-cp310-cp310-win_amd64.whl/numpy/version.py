
"""
Module to expose more detailed version info for the installed `numpy`
"""
version = "2.0.0"
__version__ = version
full_version = version

git_revision = "1d49c7f7ff527c696fc26ab2278ad51632a66660"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
